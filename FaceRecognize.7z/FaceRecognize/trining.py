# -*- coding: utf-8 -*-
"""
Created on Mon Sep 18 08:19:33 2017

@author: Bauyrzhan
"""
import os
import numpy as np
import cv2
from PIL import Image
recognizer = cv2.createLBPHFaceRecognizer();
path="C:/Users/Bauyrzhan/AnacondaProj/FaceRecognize/dataSet"
def getImagesWithID(path):
    imagePaths = [os.path.join(path, f) for f in os.listdir(path)]
    # print image_path
    #getImagesWithID(path)
    faces = []
    IDs = []
    for imagePath in imagePaths:
        # Read the image and convert to grayscale
        facesImg = Image.open(imagePath).convert('L')
        faceNP = np.array(facesImg, 'uint8')
        # Get the label of the image
        ID= int(os.path.split(imagePath)[-1].split(".")[1])
         # Detect the face in the image
        faces.append(faceNP)
        IDs.append(ID)
        cv2.imshow("Adding faces for traning",faceNP)
        cv2.waitKey(10)
    return np.array(IDs), faces
Ids,faces  = getImagesWithID(path)
recognizer.train(faces,Ids)
recognizer.save("C:/Users/Bauyrzhan/AnacondaProj/FaceRecognize/trainingdata.yml")
print('Done')
cv2.destroyAllWindows()