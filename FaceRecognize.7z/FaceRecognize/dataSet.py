import numpy as np
import cv2
face_cascade = cv2.CascadeClassifier('C:/Users/Bauyrzhan/PycharmProjects/ImgProc/EyeAndFace/haarcascade_frontalface_default.xml')
cap = cv2.VideoCapture(0)
id=raw_input("Enter id: ")

count=0
while 1:
    ret, img = cap.read()
    gray = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
    faces = face_cascade.detectMultiScale(gray, 1.5, 5)
    for (x,y,w,h) in faces:
        count+=1
        cv2.imwrite("C:/Users/Bauyrzhan/AnacondaProj/FaceRecognize/dataSet/User."+str(id)+ "." +str(count)+ ".jpg", gray[y:y+h, x:x+w])
        cv2.rectangle(img,(x-50,y-50),(x+w+50,y+h+50),(255,0,0),2)
        cv2.waitKey(100)
    cv2.imshow('img',img)
    cv2.waitKey(1)
    if count>20:
        break
print('Finished edit user')
cap.release()
cv2.destroyAllWindows()